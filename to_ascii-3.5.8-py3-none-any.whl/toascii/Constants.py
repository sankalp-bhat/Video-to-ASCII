
gradients = (  # gradients which can be chosen when creating a video object later
    ' `-~+#@',  # good for high light/contrast environments
    ' ¨\'³•µðEÆ',  # low light low contrast environments
    ' ░▒▓█',
)
